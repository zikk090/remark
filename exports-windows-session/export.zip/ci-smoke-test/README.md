﻿# CI smoke test

_Reviewed by runneradmin · Nov 23, 2026 2:06 PM · 2 notes_

## 1. [Note] — Notepad — *Untitled - Notepad

![Note 1](shots/shot-001-e312.png)

The sign-in button is hard to find

<sub>2:06 PM</sub>

---

## 2. [Note] — Notepad — *Untitled - Notepad

> Welcome to Acme. Sign in with your work email to continue.

Copy is clear

<sub>2:06 PM</sub>

---

