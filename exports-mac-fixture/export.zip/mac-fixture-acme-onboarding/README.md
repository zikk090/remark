﻿# Mac fixture — Acme onboarding

_Reviewed by Ezinne Kalu · Nov 12, 2026 10:15 AM · 2 notes_

## 1. [Bug] — Safari — Acme — Sign in

![Note 1](shots/shot-001-a1b2.png)

Button overlaps the password field on narrow screens.

<sub>10:16 AM</sub>

---

## 2. [UX] — Google Chrome

> Enter the 6-digit code we sent to your email

Say how long the code is valid for.

<sub>10:18 AM</sub>

---

